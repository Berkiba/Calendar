# Calendar
A school project about building myself a calendar for assignmnets
# Command Reminder
* `npx nodemon --exec "node --env-file=.env --import=tsx" .\server.ts` - backend.
* `npx vite` - for viewing/debugging the frontend locally.
* `./RUN.ps1` - the powershell script for Windows user to start two servers at the same time.
# Members
|Name|View|Model|Types/Interfaces|Controller|
|-|-|-|-|-|
|Berk|`Calendar`||||
|Josef|`Event Form` `Event Details`||||
|Yuze|~~`EASY_REACT_COMPONENT`~~ `Home` `SideBar` |~~`Database`~~ `MongoDB` `RepositoryDataWebsiteVisitCounter` `RepositoryManager` |~~`IDatabase`~~ `IRepositoryData`|~~`Search`~~ `LoadWebsiteVisitCounter`|

* ~~Compnent~~ This font style means once created, but deleted afterward during development.
* `.index.tsx` and `index.html` will not be counted.
*  `MyComponent` in the "**Responsible For**" field will be representing all `MyComponent.tsx`, `MyComponent.css`, `MyComponent.html` ... that begin with `MyComponent`.

# MVC Fulfillment
### Model
* `.service/` `.interface/` `.type/`
### View
* `.react/`
### Controler
* `.api`
